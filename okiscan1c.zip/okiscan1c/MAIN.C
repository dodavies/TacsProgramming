/*
  Main program for scan.exe
*/

#include <conio.h>
#include <bios.h>
#include "scan.h"
#include "ctlib.h"

struct global_struct global;		/* declare global structure here */

void main (int argc, char *argv[])
{

  if (init_oki(argc, argv) == FALSE)    /* initialize phone */
    exit(1);
  drawscreen();                         /* draw screen boxes */

  /* set initial values for globals */
  global.mute = FALSE;                  /* always-mute off */
  global.audit = TRUE;                  /* do release on audit */
  global.squelch = 20;                  /* moderate initial squelch */
  global.offset = 0;                    /* 0 OMNICELL offset */
  global.mode = IDLE_MODE;

  /* initialize static variables in functions */
  vc_scan(INIT);
  omni_scan(INIT);
  cc_mon(INIT);
  graph(INIT);
  for (;;)
  {
    update_status();
    if (bioskey(1) != 0)                /* if keypress waiting */
    {
      process_key();                    /* deal with keypress */
      global.mode = IDLE_MODE;
    }
  }
}
