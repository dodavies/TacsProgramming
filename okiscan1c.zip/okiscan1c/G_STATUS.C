/*

*/

#include <conio.h>
#include "scan.h"
#include "ctlib.h"

void graph_status(int avg, bool omni)
{

  /* update global variables */
  ct_channel_type(ct_state.channel,&global.system,&global.type);

  /* print the stuff to the status window */
  window(G_STATUS);
  cprintf("Average: %01d  Channels: %02d  Type: %c  System: %c  OMNI Offset: %02d  Graph OMNI: %c\r\n",
	avg,
	global.numchan,
	global.type,
	global.system,
	global.offset,
	omni == FALSE ? 'N' : 'Y');
  window(GRAPH);			/* set back to GRAPH window */
/*  gotoxy(GRAPHXY); */
}
